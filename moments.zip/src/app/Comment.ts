export interface Comment {
    id?: number,
    text: string,
    username: string,
    momentId: number,
    created_at?: string,
    updated_at?: string,
}