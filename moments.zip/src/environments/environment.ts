export const environment = {
    production: false,
    baseApiUrl: "http://127.0.0.1:3333/"
  };